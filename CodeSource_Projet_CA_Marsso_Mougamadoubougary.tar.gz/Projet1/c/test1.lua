local a = 4
local b = 2
local c = a + b
print(c)

local d = a - b
print(d)

local e = a * b
print(e)

local f = a / b
print(f)